package util;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import model.Edge;
import model.Graph;
import model.Node;

public class RedNodeManipulation {


    public static Graph removeRed(Graph graph, Predicate<Edge> predicate) {

        LinkedList<Node> nodes = new LinkedList<>();
        Node root = graph.getStart();
        HashMap<Node, Boolean> map = new HashMap<>();
        nodes.add(root);

        while (!nodes.isEmpty()) {
            Node node = nodes.poll();
            map.put(node, true);
            node.setEdges(node.getEdges().stream().filter(predicate)
                    .collect(Collectors.toList()));
            for (Edge edge : node.getEdges()) {
                if (map.get(edge.getEnd()) == null) {
                    nodes.push(edge.getEnd());
                }
            }
        }
        return graph;
    }
}
