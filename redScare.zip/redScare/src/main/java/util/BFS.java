package util;

import java.util.LinkedList;

import model.Edge;
import model.Graph;
import model.Node;

public class BFS {

    // useful for finding the shortest path in unweighted graph
//    O(V+E)
    public static Graph bfs(Graph graph) {

        LinkedList<Node> nodes = new LinkedList<>();
        Node root = graph.getStart();
        nodes.add(root);
//        root.setRedDistance(0);

        while (!nodes.isEmpty()) {
            Node node = nodes.poll();
            node.setDiscovered(true);
            for (Edge edge : node.getEdges()) {
                Node to = edge.getEnd();
                if (!to.isDiscovered() && !nodes.contains(to)) {
                    nodes.add(to);
                    to.setShortestTo(edge);
                }
            }
        }
        return graph;
    }
}
