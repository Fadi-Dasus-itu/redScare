import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

import model.Graph;
import parse.Parser;
import solvers.Alternate;
import solvers.Few;
import solvers.ISolve;
import solvers.None;

public class Main {
    public static void main(String[] args) {
//        for (String path : args) {

      String path = "C:/Users/fadi.dasus/OneDrive - Heartland AS/Desktop/Master first semester/Algorithm Design/hand-in/red scare/Red-Scare/data/P3.txt";
//      String path = "C:/Users/fadi.dasus/OneDrive - Heartland AS/Desktop/Master first semester/Algorithm Design/hand-in/red scare/Red-Scare/data/smallworld-3-0.txt";
//        String path = "C:/Users/fadi.dasus/OneDrive - Heartland AS/Desktop/Master first semester/Algorithm Design/hand-in/red scare/Red-Scare/data/gnm-10-20-1.txt";

        Graph graph = Parser.parse(path);
        Path p = Paths.get(path);
        String file = p.getFileName().toString();
        //rename to edge number
        System.out.print("file name: " + file + "\t" + "number of nodes: " + graph.getNodeNum() + ",\t");


        ISolve[] problems = {
                new None(), new Alternate(), new Few()
        };

        Arrays.stream(problems).forEach(i -> {
            i.solve(Parser.parse(path));

        });

    }


}
//}

