package parse;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import edu.princeton.cs.algorithms.FlowEdge;
import model.Edge;
import model.Graph;
import model.Node;

public class Parser {

    public static Graph parse(String fileLocation) {
        try (
                Scanner scanner = new Scanner(new FileReader(fileLocation));
        ) {
            boolean isDirected = false;
            String[] counts = scanner.nextLine().split(" ");
            int nodeNumber = Integer.parseInt(counts[0]);
            int edgeNumber = Integer.parseInt(counts[1]);


            HashMap<String, Node> nodes = new HashMap<>();

            Map<Node, Integer> nodeToIndex = new HashMap<>();
//            List<FlowEdge> edges4Flow = new ArrayList<>();
            HashSet<Integer> redNodes = new HashSet<>();
            String[] specialNodes = scanner.nextLine().split(" ");

            for (int i = 0; i < nodeNumber; i++) {
                String[] line = (scanner.nextLine()).split(" ");
                Node n = new Node(line[0]);
                n.setRed(line.length > 1);
                if (n.isRed()) {
                    redNodes.add(i);
                }
                nodes.put(line[0], n);
                nodeToIndex.put(n, i);
            }

            String n = scanner.nextLine();

            if (!(n.split(" ")[1].equals("--"))) {
                isDirected = true;
            }
            for (int i = 0; i < edgeNumber; i++) {
                String[] parts = n.split(" ");
                Node from = nodes.get(parts[0]);
                Node to = nodes.get(parts[2]);

                if (parts[1].equals("--")) {
                    // create both ways as is undirected
                    to.addEdge(new Edge(to, from));
                    from.addEdge(new Edge(from, to));
//
//                        FlowEdge flowEdgeFrom = new FlowEdge(nodeToIndex.get(from), nodeToIndex.get(to), 1);
//                        FlowEdge flowEdgeTo = new FlowEdge(nodeToIndex.get(to), nodeToIndex.get(from), 1);
//                        edges4Flow.add(flowEdgeFrom);
//                        edges4Flow.add(flowEdgeTo);
                } else {
                    from.addEdge(new Edge(from, to));
//                        FlowEdge flowEdgeFrom = new FlowEdge(nodeToIndex.get(from), nodeToIndex.get(to), 1);
//                        edges4Flow.add(flowEdgeFrom);
                }


                if (i == edgeNumber - 1) {
                    break;
                }
                n = scanner.nextLine();

            }
//            return new Graph(nodes.get(specialNodes[0]), nodes.get(specialNodes[1]), nodeNumber, isDirected, nodeToIndex, edges4Flow, redNodes);
            return new Graph(nodes.get(specialNodes[0]), nodes.get(specialNodes[1]), nodeNumber, isDirected, nodeToIndex, null, redNodes);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.exit(1);
        }
        return null;
    }
}
