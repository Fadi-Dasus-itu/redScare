package solvers;

import java.util.HashMap;
import java.util.LinkedList;

import model.Edge;
import model.Graph;
import model.Node;
import util.Dijkstra;

public class Few implements ISolve {
    @Override
    public void solve(Graph input) {
        var solvedGraph = Dijkstra.dijkstra(changeWeights(input));
        printResult(solvedGraph);
    }

    private Graph changeWeights(Graph input) {
        var graph = input;
        LinkedList<Node> nodes = new LinkedList<>();
        Node root = graph.getStart();
        HashMap<Node, Boolean> map = new HashMap<>();
        nodes.add(root);

        while (!nodes.isEmpty()) {
            Node node = nodes.poll();
            map.put(node, true);
            node.getEdges().forEach(e -> e.setDistance(e.getEnd().isRed() ? 1 : 0));
            for (Edge edge : node.getEdges()) {
                if (map.get(edge.getEnd()) == null) {
                    nodes.push(edge.getEnd());
                }
            }
        }
        return graph;
    }

    public void printResult(Graph solvedGraph) {
        int dist = solvedGraph.getEnd().getDistance();
        if (dist == Integer.MAX_VALUE) {
            dist = -1;
        }
        if (solvedGraph.getStart().isRed()) {
            dist += 1;
        }
        System.out.print(dist + "\t");
    }
}
