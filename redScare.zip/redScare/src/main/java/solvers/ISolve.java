package solvers;

import model.Graph;

public interface ISolve {

    void solve(Graph input);

}
