import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

import model.Graph;
import parse.Parser;
import solvers.Alternate;
import solvers.Few;
import solvers.ISolve;
import solvers.None;
import solvers.Some;

public class Main {
    public static void main(String[] args) {
        for (String path : args) {
        Graph graph = Parser.parse(path);
        Path p = Paths.get(path);
        String file = p.getFileName().toString();
        System.out.print("file name: " + file + "\t" + "number of nodes: " + graph.getNodeNum() + ",\t");


        ISolve[] problems = {
                new None(), new Alternate(), new Few(), new Some()
        };

        Arrays.stream(problems).forEach(i -> {
            i.solve(Parser.parse(path));

        });

    }


}
}

