package util;

import java.util.Iterator;

import edu.princeton.cs.algorithms.FlowEdge;
import edu.princeton.cs.algorithms.FlowNetwork;
import model.Graph;

public class FordFulkersonHelper {


    public static boolean solveFlow(Graph graph, FlowNetwork flowNetwork, int newSource, int newSink) {
        for (Integer red : graph.getRedNodes()) {
            FlowNetwork fNet = flowNetwork;
            Iterator<FlowEdge> iterator = fNet.edges().iterator();
            FlowNetwork fNetCopy = new FlowNetwork(fNet.V());
            while (iterator.hasNext()) {
                fNetCopy.addEdge(iterator.next());
            }

            FlowEdge o = new FlowEdge(newSource, red, 1);
            FlowEdge e = new FlowEdge(red, newSink, 2);
            fNetCopy.addEdge(e);
            fNetCopy.addEdge(o);
            edu.princeton.cs.algorithms.FordFulkerson fordFulk;
            try {
                fordFulk = new edu.princeton.cs.algorithms.FordFulkerson(fNetCopy,
                        newSource, newSink);
                if (Math.round(fordFulk.value()) == 2) {
                    return true;
                }
            } catch (RuntimeException a) {
            }
        }
        return false;
    }
}
