package parse;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import edu.princeton.cs.algorithms.FlowEdge;
import model.Edge;
import model.Graph;
import model.Node;

public class Parser {


    public static Graph parse(String fileLocation) {
        try (
                Scanner scanner = new Scanner(new FileReader(fileLocation));
        ) {
            // setup for parsing
            boolean isDirected = false;
            String[] counts = scanner.nextLine().split(" ");
            int nodeNumber = Integer.parseInt(counts[0]);
            int edgeNumber = Integer.parseInt(counts[1]);

            HashMap<String, Node> nodesByName = new HashMap<>();
            Map<Node, Integer> NodesByIndex = new HashMap<>();
            List<FlowEdge> edges4Flow = new ArrayList<>();
            HashSet<Integer> redNodes = new HashSet<>();
            String[] sourceAndSink = scanner.nextLine().split(" ");

            // iterate to get all the nodes from the file
            for (int i = 0; i < nodeNumber; i++) {
                String[] line = (scanner.nextLine()).split(" ");
                Node node = new Node(line[0]);
                node.setRed(line.length > 1);
                if (node.isRed()) {
                    redNodes.add(i);
                }
                nodesByName.put(line[0], node);
                NodesByIndex.put(node, i);
            }

            String line = scanner.nextLine();

            if (!(line.split(" ")[1].equals("--"))) {
                isDirected = true;
            }
            // iterate to assign edges
            for (int i = 0; i < edgeNumber; i++) {
                String[] parts = line.split(" ");
                Node from = nodesByName.get(parts[0]);
                Node to = nodesByName.get(parts[2]);

                // duplicate edges if the graph is undirected
                if (parts[1].equals("--")) {
                    // create both ways as is undirected
                    to.addEdge(new Edge(to, from));
                    from.addEdge(new Edge(from, to));

                        FlowEdge flowEdgeFrom = new FlowEdge(NodesByIndex.get(from), NodesByIndex.get(to), 1);
                        FlowEdge flowEdgeTo = new FlowEdge(NodesByIndex.get(to), NodesByIndex.get(from), 1);
                        edges4Flow.add(flowEdgeFrom);
                        edges4Flow.add(flowEdgeTo);
                } else {
                    from.addEdge(new Edge(from, to));
                        FlowEdge flowEdgeFrom = new FlowEdge(NodesByIndex.get(from), NodesByIndex.get(to), 1);
                        edges4Flow.add(flowEdgeFrom);
                }

                if (i == edgeNumber - 1) {
                    break;
                }
                line = scanner.nextLine();

            }

//     Graph(Node start, Node end, int nodeNum, boolean isDirected, Map<Node, Integer> nodes, List<FlowEdge> edgesForFlow, HashSet<Integer> redNodes)
            return new Graph(nodesByName.get(sourceAndSink[0]), nodesByName.get(sourceAndSink[1]), nodeNumber, isDirected, NodesByIndex, edges4Flow, redNodes);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.exit(1);
        }
        return null;
    }

}
