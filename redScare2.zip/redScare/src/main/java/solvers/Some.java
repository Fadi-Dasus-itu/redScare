package solvers;

import edu.princeton.cs.algorithms.FlowEdge;
import edu.princeton.cs.algorithms.FlowNetwork;
import model.Graph;
import util.FordFulkersonHelper;

public class Some implements ISolve {

    private boolean result = false;

    @Override
    public void solve(Graph graph) {
        FlowNetwork flowNetwork = new FlowNetwork(graph.getNodeNum() + 2);
        for (FlowEdge FE : graph.getEdgesForFlow()) {
            flowNetwork.addEdge(FE);
        }
        //create new source, connect to old source and to old sink
        var newSource = graph.getNodeNum();
        var newSink = graph.getNodeNum() + 1;
        flowNetwork.addEdge(new FlowEdge(newSource, graph.getNodes().get(graph.getStart()), 1));
        flowNetwork.addEdge(new FlowEdge(graph.getNodes().get(graph.getEnd()), newSource, 1));
        //solve some
        result = FordFulkersonHelper.solveFlow(graph, flowNetwork, newSource, newSink);

        printResult();
    }

    public void printResult() {
        System.out.print("some : " + result + "\t");
    }
}
