package solvers;

import model.Graph;
import model.Node;
import util.BFS;
import util.RedNodeManipulation;

public class None implements ISolve {


    @Override
    public void solve(Graph input) {
        var removedRedGraph = RedNodeManipulation.removeRed(input,
                e -> !e.getEnd().isRed() || e.getEnd() == input.getEnd());
        printResult(BFS.bfs(removedRedGraph));

    }


    public void printResult(Graph bfsGraph) {
        System.out.print("none path: " + pathExists(bfsGraph) + ",\t");
    }

    private int pathExists(Graph bfsGraph) {
        Node n = bfsGraph.getEnd();
        int i = 0;
        while (true) {
            if (n.getShortestTo() == null) {
                break;
            }
            n = n.getShortestTo().getStart();
            i += 1;
        }
        return n == bfsGraph.getStart() ? i : -1;
    }
}

