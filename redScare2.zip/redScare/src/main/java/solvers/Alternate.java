package solvers;

import model.Graph;
import model.Node;
import util.BFS;
import util.RedNodeManipulation;

public class Alternate implements ISolve {

    @Override
    public void solve(Graph input) {
        var removedRedGraph =
                RedNodeManipulation.removeRed(input, e -> e.getEnd().isRed() != e.getStart().isRed());
        printResult(BFS.bfs(removedRedGraph));

    }

    public void printResult(Graph bfsGraph) {
        System.out.print("is alternate: " + pathExists(bfsGraph) + ",\t");
    }

    private boolean pathExists(Graph bfsGraph) {
        Node n = bfsGraph.getEnd();
        while (n != null) {
            if (n.getShortestTo() == null) {
                break;
            }
            n = n.getShortestTo().getStart();
        }

        return n == bfsGraph.getStart();
    }


}
